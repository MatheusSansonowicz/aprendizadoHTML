package com.example.aprendizadohtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AprendizadoHtmlApplicationTests {

    @Test
    void contextLoads() {
    }

}
